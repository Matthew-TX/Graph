import org.junit.Assert;

import java.util.ArrayList;

public class Starter {
    public static void main(String[] args) {

    }
}
